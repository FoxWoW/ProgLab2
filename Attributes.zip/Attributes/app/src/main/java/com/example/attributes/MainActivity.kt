package com.example.attributes

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.TypedValue
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val size_8sp = 8
        val size_24sp = 24
        val tv : EditText = findViewById(R.id.textAssist)
        val Button1: Button = findViewById(R.id.Button1)
        Button1. setOnClickListener {
            tv.setTextColor(Color.BLACK)
        }
        val Button2: Button = findViewById(R.id.Button2)
        Button2. setOnClickListener {
            tv.setTextColor(Color.RED)
        }
        val Button3: Button = findViewById(R.id.Button3)
        Button3. setOnClickListener {
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, size_8sp.toFloat());
        }
        val Button4: Button = findViewById(R.id.Button4)
        Button4. setOnClickListener {
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, size_24sp.toFloat());
        }
        val Button5: Button = findViewById(R.id.Button5)
        Button5. setOnClickListener {
            tv.setBackgroundColor(Color.WHITE)

        }
        val Button6: Button = findViewById(R.id.Button6)
        Button6. setOnClickListener {
            tv.setBackgroundColor(Color.BLACK)
        }

    }
}